<?php

class ContatoController extends Controller
{
  public function index()
  {
    $this->view('contato');
  }
}
