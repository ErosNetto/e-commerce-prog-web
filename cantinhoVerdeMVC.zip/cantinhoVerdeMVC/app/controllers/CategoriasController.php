<?php

class CategoriasController extends Controller
{
  public function index()
  {
    $this->view('categoria');
  }
}
