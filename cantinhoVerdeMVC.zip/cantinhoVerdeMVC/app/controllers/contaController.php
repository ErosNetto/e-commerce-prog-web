<?php

class ContaController extends Controller
{
  public function index()
  {
    $this->view('conta');
  }
}
