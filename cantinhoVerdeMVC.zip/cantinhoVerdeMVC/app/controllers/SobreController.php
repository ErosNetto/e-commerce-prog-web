<?php

class SobreController extends Controller
{
  public function index()
  {
    $this->view('sobre');
  }
}
