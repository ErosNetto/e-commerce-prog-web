<?php

class CadastroController extends Controller
{
  public function index()
  {
    $this->view('cadastro');
  }
}
